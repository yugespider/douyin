from flask import Flask, jsonify, request
from getip import GETIP
import time

app = Flask(__name__)


@app.route('/index', methods=['GET'])
def index():
    key = request.args.get('key')
    if key != '123321':
        return jsonify({'code': 4999, 'data': '令牌无效'})
    ok_ip = GETIP().run()
    time.sleep(3)
    if ok_ip:
        return jsonify({'code': 200, 'data': {'http': ok_ip}})
    return jsonify({'code': 5000, 'data': '获取失败，请重新请求'})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8456)
